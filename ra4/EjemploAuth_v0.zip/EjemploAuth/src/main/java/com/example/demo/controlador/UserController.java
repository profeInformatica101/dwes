package com.example.demo.controlador;

import java.time.LocalDateTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Slice;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.demo.dto.UsuarioDTO;
import com.example.demo.entidad.Comentario;
import com.example.demo.entidad.Usuario;
import com.example.demo.servicio.ComentarioServicio;
import com.example.demo.servicio.UsuarioServicio;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;

@Controller
@RequestMapping("/user")
public class UserController {
	
	@Autowired
	ComentarioServicio comentariosServicio;
	@Autowired
	UsuarioServicio usuarioServicio;

	private final String HOME = "auth/user/home";

    @GetMapping("/home")
    @PreAuthorize("hasRole('USER')")
    public String user(Model model, @RequestParam(value = "page", defaultValue = "0") int page,
            @RequestParam(value = "size", defaultValue = "5") int size, HttpServletRequest request ) {
    	model.addAttribute("comentario", new Comentario());

        Slice<Comentario> sliceComentarios = comentariosServicio.listarTodosComoSlice(PageRequest.of(page, size));
        
        int currentPage = page;
        int startPage = Math.max(0, currentPage - 2);
        int endPage = currentPage + 2; // Asume un rango fijo de páginas alrededor de la página actual

        model.addAttribute("startPage", startPage);
        model.addAttribute("endPage", endPage);
        model.addAttribute("comentarios", sliceComentarios.getContent());
        model.addAttribute("requestURI", request.getRequestURI());
        model.addAttribute("hasNext", sliceComentarios.hasNext());
        model.addAttribute("hasPrevious", sliceComentarios.hasPrevious());
        model.addAttribute("currentPage", currentPage);
    	
        return HOME; // Muestra la página específica del usuario (user.html)
    }
   @GetMapping("/agregarComentario")
   public String mostrarFormularioComentario(Model model) {
	   
	   Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
	    String username = authentication.getName();
	 // Obtener UsuarioDTO en lugar de la entidad Usuario completa
        UsuarioDTO usuarioDTO = usuarioServicio.obtenerUsuarioDTO(username);
	    
	   System.out.println("############# id:" +usuarioDTO.getId());
	 
	// Crear una nueva instancia de Comentario y añadirla al modelo
       Comentario comentario = new Comentario();
       comentario.setFechaCreacion(LocalDateTime.now());
       model.addAttribute("comentario", comentario);
       model.addAttribute("usuarioDTO", usuarioDTO); // Añadir el UsuarioDTO al modelo si es necesario

	   return "/auth/user/formCrearComentario";
   }
   @PostMapping("/agregarComentario")
   public String agregarComentario(@Valid @ModelAttribute("comentario") Comentario comentario, 
                                   BindingResult result, 
                                   @RequestParam("usuarioId") Long usuarioId, 
                                   Model model) {
       if (result.hasErrors()) {
           return "/auth/user/formCrearComentario";
       }
       // Busca el usuario por el ID capturado
       Usuario usuario = usuarioServicio.obtenerPorId(usuarioId);
       // Asocia el usuario al comentario
       comentario.setUsuario(usuario);
       
       System.out.println("## contenido ## " + comentario.toString());
       
       comentariosServicio.guardar(comentario);
       return "redirect:/user/home";
   }
    
	
	 
	
}