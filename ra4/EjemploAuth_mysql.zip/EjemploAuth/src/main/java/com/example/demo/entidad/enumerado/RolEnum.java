package com.example.demo.entidad.enumerado;

public enum RolEnum {
	ROLE_USER,
    ROLE_ADMIN
}
