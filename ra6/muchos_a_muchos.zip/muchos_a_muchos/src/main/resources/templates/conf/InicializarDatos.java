package com.example.demo.conf;

import com.example.demo.entidad.Curso;
import com.example.demo.entidad.Estudiante;
import com.example.demo.repositorio.CursoRepositorio;
import com.example.demo.repositorio.EstudianteRepositorio;
import com.github.javafaker.Faker;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;


import java.time.ZoneId;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;


@Component
public class InicializarDatos implements CommandLineRunner {

    @Autowired
    private EstudianteRepositorio estudianteRepositorio;

    @Autowired
    private CursoRepositorio cursoRepositorio;

    @Override
    public void run(String... args) throws Exception {
    	final Integer NUMERO_DE_ESTUDIANTES = 10;
    	final Integer NUMERO_DE_CURSOS = 10;
    	Faker faker = new Faker();

        // Crear y guardar cursos ficticios
        for (int i = 0; i < NUMERO_DE_CURSOS; i++) {
            Curso curso = new Curso();
            curso.setTitulo(faker.educator().course());
            curso.setDescripcion(faker.lorem().sentence());
           
            cursoRepositorio.save(curso);
        }

        List<Curso> cursosDisponibles = cursoRepositorio.findAll();

        // Crear y guardar estudiantes ficticios
        for (int i = 0; i < NUMERO_DE_ESTUDIANTES; i++) {
            Estudiante estudiante = new Estudiante();
            estudiante.setNombre(faker.name().fullName());
            estudiante.setEmail(faker.internet().emailAddress());
            estudiante.setFechaNacimiento(faker.date().birthday().toInstant().atZone(ZoneId.systemDefault()).toLocalDate());
     

            Random random = new Random();
            int numeroDeCursos = 2 + random.nextInt(2); 
            Set<Curso> cursosAsignados = new HashSet<>();

            for (int j = 0; j < numeroDeCursos; j++) {
                cursosAsignados.add(cursosDisponibles.get(random.nextInt(cursosDisponibles.size())));
            }

            estudiante.setCursos(cursosAsignados);
            estudianteRepositorio.save(estudiante);
        }
    }
}
