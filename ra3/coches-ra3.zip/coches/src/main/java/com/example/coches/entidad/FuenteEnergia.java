package com.example.coches.entidad;

public enum FuenteEnergia {
	GASOLINA,
	DIESEL,
    ELECTRICO,
    HIBRIDO,
    HIDROGENO
}
