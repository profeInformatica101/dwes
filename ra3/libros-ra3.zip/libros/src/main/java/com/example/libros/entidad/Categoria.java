package com.example.libros.entidad;
/**
 * Categorias de los libros
 * 
 * Nota: El método Categoria.values()  devuelve un Array de Categoria
 */
public enum Categoria {
	ROMANCE, POESIA, FANTASIA, CIENCIA_FICCION, HISTORIA, DIDACTICOS, HORROR, TEST
}

