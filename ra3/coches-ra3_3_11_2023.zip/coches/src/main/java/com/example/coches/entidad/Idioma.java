package com.example.coches.entidad;

public enum Idioma {
	ES,
	EN
}
